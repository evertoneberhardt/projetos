var dados = { "JANEIRO" : [ 
			{ "dia":"14" , "evento":"Terreira Ogum de Mallê", "dia_semana":"Sábado, 18:00h" },
			{ "dia":"28" , "evento":"Terreira Ogum de Mallê", "dia_semana":"Sábado, 18:00h" } ],

			"FEVEREIRO" : [ 
			{ "dia":"01" , "evento":"Terreira Iemanjá", "dia_semana":"Quarta-feira, 18:00h" } ],

			"MARÇO" : [ 
			{ "dia":"11" , "evento":"Terreira Ogum de Mallê", "dia_semana":"Sábado, 18:00h" },
			{ "dia":"25" , "evento":"Batuque", "dia_semana":"Sábado, 23:00h" } ],

			"ABRIL" : [ 
			{ "dia":"08" , "evento":"Terreira Ogum de Mallê", "dia_semana":"Sábado, 18:00h" },
			{ "dia":"15" , "evento":"Romper aleluia", "dia_semana":"Sábado, 06:00h" },
			{ "dia":"22" , "evento":"Terreira Ogum de Mallê", "dia_semana":"Sábado, 18:00h" },
			{ "dia":"23" , "evento":"Dia de Ogum", "dia_semana":"Domingo" } ],

			"MAIO" : [ 
			{ "dia":"06" , "evento":"Terreira Ogum de Mallê", "dia_semana":"Sábado, 18:00h" },
			{ "dia":"13" , "evento":"Dia de preto-velho na Umbanda", "dia_semana":"Sábado" },
			{ "dia":"20" , "evento":"Terreira Preto Velho", "dia_semana":"Sábado, 18:00h" } ],

			"JUNHO" : [ 
			{ "dia":"03" , "evento":"Terreira Ogum de Mallê", "dia_semana":"Sábado, 18:00h" },
			{ "dia":"17" , "evento":"Terreira Ogum de Mallê", "dia_semana":"Sábado, 18:00h" } ],

			"JULHO" : [ 
			{ "dia":"01" , "evento":"Terreira Ogum de Mallê", "dia_semana":"Sábado, 18:00h" },
			{ "dia":"15" , "evento":"Terreira Ogum de Mallê", "dia_semana":"Sábado, 18:00h" },
			{ "dia":"29" , "evento":"Terreira Ogum de Mallê", "dia_semana":"Sábado, 18:00h" } ],

			"AGOSTO" : [ 
			{ "dia":"11" , "evento":"Terreira Ogum de Mallê", "dia_semana":"Sexta-feira, 20:00h" },
			{ "dia":"26" , "evento":"Terreira Ogum de Mallê", "dia_semana":"Sábado, 18:00h" } ],

			"SETEMBRO" : [ 
			{ "dia":"09" , "evento":"Terreira Ogum de Mallê", "dia_semana":"Sábado, 18:00h" },
			{ "dia":"23" , "evento":"Terreira Ogum de Mallê", "dia_semana":"Sábado, 18:00h" },
			{ "dia":"27" , "evento":"Dia de Cosme e Damião", "dia_semana":"Quarta-feira" } ],

			"OUTUBRO" : [ 
			{ "dia":"07" , "evento":"Terreira Ogum de Mallê", "dia_semana":"Sábado, 18:00h" },
			{ "dia":"14" , "evento":"Batuque Mãe Iansã", "dia_semana":"Sábado, 18:00h" },
			{ "dia":"21" , "evento":"Peixe Manhã, Terreira", "dia_semana":"Sábado, 18:00h" } ],
			"NOVEMBRO" : [ 
			{ "dia":"04" , "evento":"Terreira Ogum de Mallê", "dia_semana":"Sábado, 18:00h" },
			{ "dia":"15" , "evento":"Dia da Umbanda", "dia_semana":"Quarta-feira" },
			{ "dia":"18" , "evento":"Terreira Ogum de Mallê", "dia_semana":"Sábado, 18:00h" } ],

			"DEZEMBRO" : [ 
			{ "dia":"02" , "evento":"Terreira Ogum de Mallê", "dia_semana":"Sábado, 18:00h" },
			{ "dia":"09" , "evento":"Batuque", "dia_semana":"Sábado, 18:00h" },
			{ "dia":"16" , "evento":"Peixe manhã, Terreira", "dia_semana":"Sábado, 18:00h" },
			{ "dia":"25" , "evento":"Dia de Oxalá", "dia_semana":"Segundo-feira" } ]

		};

